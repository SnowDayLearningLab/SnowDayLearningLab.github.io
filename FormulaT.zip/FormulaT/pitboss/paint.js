var WIDTH = 700;
var HEIGHT = 450;
var GWIDTH = 350;
var GHEIGHT = 250;

var id = localStorage.getItem("id");
var age = localStorage.getItem("age");
var players = sessionStorage.getItem("players");
var device;

var trackSelected;
var playerName;
var background;
var sqtrack1;
var fig8track1;
var cornerTrack1;
var player1;
var nodeArray;
var dataArray;
var line;

var clock;
var timer;
var savedTime;
var clockRunning = false;
var timerRunning = false;
var result = "none";
var lastFlag;
var source;

var drawing;
var touchable = "createTouch" in document;
var bubble = new google.bookmarkbubble.Bubble();
var parameter = 'bmb=1';

function init() {
    setup();
    graphinit();
    if (graphActive){
	clearImages();
	toggleTrackImages();
    }
    if (sessionStorage.getItem("name") != null){
	sessionStorage.removeItem("name");
    }
    loadBubble();
}

function setup() {
    var ptcanvas = document.getElementById("paint");
    var trcanvas = document.getElementById("track");
    var carcan = document.getElementById("car");
    var brushColor = document.getElementById("brushColor");
    ptcanvas.width = WIDTH;
    ptcanvas.height = HEIGHT;
    trcanvas.width = WIDTH;
    trcanvas.height = HEIGHT;
    carcan.width = WIDTH;
    carcan.height = HEIGHT;
    ptcontext = ptcanvas.getContext('2d');
    trcontext = trcanvas.getContext('2d');
    carcontx = carcan.getContext('2d');
    
    // Prevent elastic scrolling in iphone / ipad apps
    document.ontouchmove = function(evt) {
	evt.preventDefault();
    }
    
    if (ptcanvas) {
	if (isIPad() || isIPhone()) {
	    carcan.ontouchstart = touchDown;
	    carcan.ontouchmove = touchDrag;
	    carcan.ontouchend = touchUp;
	    device = "touch";
	} else {
	    carcan.onmouseup = mouseUp;
	    carcan.onmousemove = mouseMove;
	    carcan.onmousedown = mouseDown;
	    carcan.onmouseout = mouseOut;
	    device = "mouse";
	}
    }
    
    trackSelected = document.getElementById("tracks").selectedIndex;
    background = new blankBackground();
    
    // create tracks
    if (trackSelected==0) {
	sqtrack1 = new sqtrack();
	nodeArray = [];
	background.draw(ptcontext);
	sqtrack1.draw(trcontext);
	getSqNodes();
    } else if (trackSelected==1) {
	fig8track1 = new fig8track();
	nodeArray = [];
	background.draw(ptcontext);
	fig8track1.draw(trcontext);
	getfig8Nodes();
    } else {
	cornertrack1 = new cornertrack();
	nodeArray = [];
	background.draw(ptcontext);
	cornertrack1.draw(trcontext);
	getCornerNodes();
    }
    
    // create entities
    player1 = new playerCar(600, 173, 0, 0, Math.PI/2, 0); // x, y, vel, acc, heading, currNode
    player1.draw(carcontx);
    
    drawing = false;  // sets drawing flag to false
    wipeMessages();
    wipeTimes();
}

function isIPad() {
    return (navigator.userAgent.indexOf("iPad") != -1);
}

function isIPhone() {
    return (navigator.userAgent.indexOf("iPhone") != -1);
}

function loadBubble() {
    bubble.hasHashParameter = function() {
      return window.location.hash.indexOf(parameter) != -1;
    };
    bubble.setHashParameter = function() {
      if (!this.hasHashParameter()) {
        window.location.hash += parameter;
      }
    };
    bubble.showIfAllowed();
}

//// RADIANS TO DEGREES CONVERSION
//function ra_de(ra) {
//    var pi = Math.PI;
//    var deg = ra * (180/pi);
//    return deg;
//}
//// DEGREES TO RADIANS CONVERSION
//function de_ra(de) {
//    var pi = Math.PI;
//    var ra = de * (pi/180);
//    return ra;
//}

//-----------------------//
//    RACE FUNCTION!!    //
//-----------------------//
function race() {
    var button = document.getElementById('Race');
    if (player1.goFlag == 0) {
	result = "win";
	stopCar();
	stopClock(result);
	stopTimer();
	// logRun(result);
    } else if (player1.goFlag == 2) {
	result = "fail";
	stopCar();
	stopClock(result);
	stopTimer();
	// logRun(result);
    } else {
        button.disabled = true;
        
        player1.goFlag = endcheck();
        // CHECK COLOR AND UPDATE MAX VELOCITY
        var colorAhead = colorcheck(2);
        if (!graphMade) {			// if driving by paint
	    switch (colorAhead.data[0]) {	// set maxvel based on color
		case 124: //VIOLET
		    player1.maxvel = 1;
		    break;
		case 52: //BLUE
		    player1.maxvel = 3;
		    break;
		case 84: //CYAN
		    player1.maxvel = 5;
		    break;
		case 241: //ORANGE
		    player1.maxvel = 7;
		    break;
		case 215: //RED
		    player1.maxvel = 9;
		    break;
		case 0: //BLACK
		    player1.maxvel = 15;
		    break;
	    }
	    if ((player1.vel - player1.maxvel) >= 3){   // if you try to slow down too quickly, crash
		toggle("speedMessage");
		player1.goFlag = 2;
	    } else if ((player1.vel - player1.maxvel) >= 0.5){  // if you're moving to a slower color, slow down
		player1.vel -= 0.1;
	    } else {
	    player1.vel += 0.05;			// otherwise, speed up at this rate
	    }
    
	} else {
	    player1.grabNodeValues();		// if driving by graph
	    if (player1.accel > 0 && player1.vel > player1.maxvel){	// if you've reached target speed, keep at target speed
		player1.vel = player1.maxvel;
	    } else if (player1.accel < 0 && player1.vel < player1.maxvel){ 
		player1.vel = player1.maxvel;
	    } else {
	    player1.vel += (player1.accel * .1)  // otherwise, change vel according to accel factor
	    }
	    paint(player1.x, player1.y, 10);
	}
        player1.checkNode(player1.x, player1.y);
        player1.update();
        carcontx.clearRect (0, 0, WIDTH, HEIGHT);
        player1.draw(carcontx);
	updateTimer();
	updateClock();
    }
}

function tick() {
    resetCar();
    startTimer();
    startClock();
    player1.raceCar = setInterval(race, 30);
}

function endcheck() {
    var colorAhead = colorcheck(1);
    if (colorAhead.data[0] == 204 && colorAhead.data[1] == 255) {
        //toggle("finishMessage"); don't toggle until response gotten
        return 0;
    } else if (colorAhead.data[0] == 25){
        toggle("crashMessage");
        return 2;
    } else {
        return 1;
    }
    return null;
}

function colorcheck(layer) {
    if (layer==1){
	return trcontext.getImageData((player1.x + player1.xvel), (player1.y + player1.yvel), 1, 1);
    } else {
	return ptcontext.getImageData((player1.x + player1.xvel), (player1.y + player1.yvel), 1, 1);
    }
}

function toggle(ID) {
    var ele = document.getElementById(ID);
    if(ele.style.display == "none") {
	ele.style.display = "block";
    }
    else {
	ele.style.display = "none";
    }
}

function toggleButton(ID) {
    var ele = document.getElementById(ID);
    ele.disabled = !ele.disabled;
}

function toggleZ(ID){
    var ele = document.getElementById(ID);
    switch (ele.style.zIndex) {
	case "5":
	    ele.style.zIndex = "0"; // if graph up, move down
	    break;
	case "6":
	    ele.style.zIndex = "1";
	    break;
	case "0":
	    ele.style.zIndex = "5"; // if graph down, move up
	    break;
	case "1":
	    ele.style.zIndex = "6";
	    break;
    }
    
}

function toggleHelp(){
    var ele;
    var ele2 = document.getElementById("helpButton");
    if (ele2.innerHTML == "Hide Help"){
	for (var i=1; i < 7; i++){
	    ele = document.getElementById("help"+i);
	    if(ele.style.display == "block") {
		ele.style.display = "none";
	    }
	}
	ele2.innerHTML = "Show Help";
    } else {
	ele2.innerHTML = "Hide Help";
	ele = document.getElementById("help1");
	ele.style.display = "block";
    }
}

function nextHelp(){
    var ele;
    var ele1;
    var ele2;
    for (var i=1; i < 7; i++){
	ele = document.getElementById("help"+i);
	if(ele.style.display == "block") {
	    ele1 = ele;
	    ele2 = document.getElementById("help"+(i+1));
	}
    }
    ele1.style.display = "none";
    ele2.style.display = "block";
}

function backHelp(){
    var ele;
    var ele1;
    var ele2;
    for (var i=1; i < 7; i++){
	ele = document.getElementById("help"+i);
	if(ele.style.display == "block") {
	    ele1 = ele;
	    ele2 = document.getElementById("help"+(i-1));
	}
    }
    ele1.style.display = "none";
    ele2.style.display = "block";
}

function initializeClocks() {
    clockRunning = false;
    timerRunning = false;
    clock = 0;
    if (trackSelected==0){
	timer = 13;
    } else {
	timer = 20;
    }
    document.getElementById("timer").innerHTML = "Curr Time = 0.00";
}

function stopClock(result) {
    var track = trackToName(trackSelected);
    if (clockRunning) {
	clockRunning = false;
	if (result == "win"){
	    document.getElementById("lastTime").innerHTML = "Last Time = " + clock;
	    if (savedTime == null || clock < savedTime) {
		savedTime = clock;
		document.getElementById("bestTime").innerHTML = "Best Time = " + savedTime;
		if (sessionStorage.getItem(track) == null || sessionStorage.getItem(track) > savedTime) { //best score
			toggle("finishMessage");
		    // checkScore(true, false);
		} else {
			toggle("finishMessage");
		    // checkScore(false, false);
		}
	    } 
	    // else {
	    // checkScore(false, false);
	    // }
	}
    }
}

function startClock(){
    if (clockRunning == false) {
	clockRunning = true;
	clock = 0;
    }
}

function updateClock() {
    if (clockRunning) {
	clock = Math.round((clock + 0.03) * 100)/100;
	document.getElementById("timer").innerHTML = "Curr Time = " + clock;
    }
}

function startTimer() {
    if (trackSelected==0){
	timer = 13;
    } else {
	timer = 18;
    }
    timerRunning = true;
}

function stopTimer() {
    if (timerRunning){
	timerRunning = false;
    }
}

function updateTimer() {
    if (timerRunning){
	if (timer <= 0) {
	    stopTimer();
	    stopClock();
	    toggle("timeMessage");
	    player1.goFlag = 2;
	} else {
	    timer = Math.round((timer - 0.03) * 100)/100;
	}
    }
}

//-----------------------//
//     EVENTS            //
//-----------------------//

function mouseDown(event) {
    if (!graphActive){
	// get the mouse location
	var mx = event.pageX;
	var my = event.pageY;
	var r = 20;
	if (!drawing) {
	    drawing = true;
	    paint(mx, my, r);
	}
    }
}

function mouseMove(event) {
    if (!graphActive){
	var mx = event.pageX;
	var my = event.pageY;
	var r = 20;
	if ( drawing ) {  // check drawing flag
	    paint(mx, my, r);
	}
    }
}

function mouseUp(event) {
    if (!graphActive){
    drawing = false; // on mouseup, set the drawing flag to false
    }
}

function mouseOut(event) {
    if (!graphActive){
	drawing = false;
    }
}

function touchDown(event) {
    if (!graphActive){
	// get the mouse location
	for (var i=0; i<event.changedTouches.length; i++) {
	    var t = event.changedTouches[i];
	    var tx = t.pageX;
	    var ty = t.pageY;
	    var r = 20;
	    drawing = true;
	    paint(tx, ty, r);       
	}
    }
}

function touchDrag(event) {
    if (!graphActive){
	for (var i=0; i<event.changedTouches.length; i++) {
	    var t = event.changedTouches[i];
	    var tx = t.pageX;
	    var ty = t.pageY;
	    var r = 20;
	    if (drawing ) {
		paint(tx, ty, r);
	    }        
	}
    }
}

function touchUp(event) {
    if (!graphActive){
	if (event.touches.length == 0) {
	    drawing = false;
	}
    }
}

function checkScore(best, show) {
    var xmlhttp = new XMLHttpRequest();
    var trackName = trackToName(trackSelected);
    xmlhttp.onreadystatechange=function() {
	// continue if the process is completed
	if (xmlhttp.readyState == 4) {
	    // continue only if HTTP status is "OK"
	    if (xmlhttp.status == 200) {
		document.getElementById("finishText").innerHTML=xmlhttp.responseText;
		checkForName();
		toggle("finishMessage");
	    }
	}
    }
    xmlhttp.open("GET","check.php?time="+savedTime+"&track="+trackName+"&best="+best+"&show="+show,true);
    xmlhttp.send();
}

function submitScore(newPlayer) {
    playerName = document.getElementById('playerName').value;
    sessionStorage.setItem("name", playerName);
    var trackName = trackToName(trackSelected);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange=function() {
	// continue if the process is completed
	if (xmlhttp.readyState == 4) {
	    // continue only if HTTP status is "OK"
	    if (xmlhttp.status == 200) {
		document.getElementById("finishText").innerHTML=xmlhttp.responseText;
	    }
	}
    }
    xmlhttp.open("GET","write.php?time="+savedTime+"&track="+trackName+"&playerName="+playerName+"&newPlayer="+newPlayer,true);
    xmlhttp.send();
}

function checkForName() {
    var nameText = document.getElementById("playerName")
    if (nameText != null){
	if (sessionStorage.getItem("name") == null) {
	    nameText.defaultValue = "Enter Name";
	} else {
	    nameText.defaultValue = sessionStorage.getItem("name");
	}
    }
}

function checkPlayer() { // check to see if we have a saved score in local storage, if we do run check score as if you didn't get a best time
    var newPlayer;
    var track = trackToName(trackSelected);
    if (sessionStorage.getItem(track) == null) {
	newPlayer = true;
	sessionStorage.setItem(track, savedTime);
	// submitScore(newPlayer);
    } else if (savedTime < sessionStorage.getItem(track)){
	newPlayer = false;
	sessionStorage.setItem(track, savedTime);
	// submitScore(newPlayer);
    } 
 //    else {
	// checkScore(false, false);
 //    }
}

//-----------------------//
//   BUTTON FUNCTIONS    //
//-----------------------//

function wipePaint() {
    var r=confirm("Are you sure you want to clear the paint from the track?");
    if (r==true){
	background.draw(ptcontext);
	//sqtrack1.draw(trcontext);
	player1.draw(carcontx);
	//nodeDraw();
	wipeMessages();
    }
}

function resetCar() {
    //writeIMG(result);
    stopCar();
    initializeClocks();
    carcontx.clearRect (0, 0, WIDTH, HEIGHT);
    player1 = new playerCar(600, 173, 0, 0, Math.PI/2, 0); // x, y, vel, acc, heading, currNode
    player1.draw(carcontx);
    dataArray = [0];
    graphupdate();
    wipeMessages();
}

function wipeMessages(){
    var mess1 = document.getElementById("crashMessage");
    var mess2 = document.getElementById("speedMessage");
    var mess3 = document.getElementById("finishMessage");
    var mess4 = document.getElementById("timeMessage");
    if (mess1.style.display == "block" || mess2.style.display == "block" || mess3.style.display == "block" || mess4.style.display == "block") {
        mess1.style.display = "none";
        mess2.style.display = "none";
        mess3.style.display = "none";
	mess4.style.display = "none";
    }
    //document.getElementById("finishText").innerHTML="";
}

function wipeTimes(){
    savedTime = null;
    document.getElementById("lastTime").innerHTML = "Last Time = ";
    document.getElementById("bestTime").innerHTML = "Best Time = ";
}

function clearImages(){
    document.getElementById("square").style.display = "none";
    document.getElementById("fig8").style.display = "none";
    document.getElementById("corners").style.display = "none";
}

function selectTrack(){
    trackSelected = document.getElementById("tracks").selectedIndex;
}

function trackToName(trackNum) {
    switch (trackNum){
	case 0:
	    return "square";
	    break;
	case 1:
	    return "figure8";
	    break;
	case 2:
	    return "corners";
	    break;
    }
}

function toggleTrackImages(){
    switch (trackSelected){
	case 0:
	    toggle("square");
	    break;
	case 1:
	    toggle("fig8");
	    break;
	case 2:
	    toggle("corners");
	    break;
    }
}

function getCookie(name) {
	var cookieValue = null;
	if (document.cookie && document.cookie != '') {
	    var cookies = document.cookie;
	    for (var i = 0; i < cookies.length; i++) {
	        // Does this cookie string begin with the name we want?
	        if (cookies.substring(0, name.length + 1) == (name + '=')) {
	            cookieValue = decodeURIComponent(cookies.substring(name.length + 1));
	            break;
	        }
	    }
	}
	return cookieValue;
}

function logRun(result) {
    var date = new Date().toLocaleString();
    getNodeColors();
    var nodeData = JSON.stringify(nodeArray)
    var csrftoken = getCookie('csrftoken');

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange=function() {
	// continue if the process is completed
	if (xmlhttp.readyState == 4) {
	    // continue only if HTTP status is "OK"
	    if (xmlhttp.status == 200) {
		tns=xmlhttp.responseText;
	    }
	}
    }

    xmlhttp.open("POST","http://127.0.0.1:8000/postrun/",true);
    xmlhttp.setRequestHeader("X-CSRFToken", csrftoken);
    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xmlhttp.send('date='+date+'&playerJSId='+id+'&age='+age+'&numPlayers='+players+'&trackNum='+trackSelected+'&device='+device+'&result='+result+'&time='+savedTime+'&nodeData='+nodeData);
}

// function postData() {
// 		var date = new Date();
// 		var playerJSId = 1435777636611;
// 		var playerName = document.getElementById('playerName');
// 		var trackNum = 0;
// 		var device = "MOUSE";
// 		var result = "WIN";
// 		var time = 37;
// 		var nodeData = [[1,"BLACK"],[2,"BLACK"],[3,"BLACK"],[4,"BLACK"],[5,"BLACK"],[6,"BLACK"],[7,"BLACK"],[8,"BLACK"],[9,"BLACK"],[10,"BLACK"],[11,"BLACK"],[12,"BLACK"],[13,"BLACK"],[14,"BLACK"],[15,"BLACK"],[16,"BLACK"],[17,"BLACK"],[18,"BLACK"],[19,"BLACK"],[20,"BLACK"]];

// 		var csrftoken = getCookie('csrftoken');

// 		var xmlhttp = new XMLHttpRequest();
// 		xmlhttp.onreadystatechange=function() {
// 			// continue if the process is completed
// 			if (xmlhttp.readyState == 4) {
// 			    // continue only if HTTP status is "OK"
// 			    if (xmlhttp.status == 200) {
// 				tns=xmlhttp.responseText;
// 			    }
// 			}
// 		}
// 		xmlhttp.open("POST","/postrun/",true);
// 		xmlhttp.setRequestHeader("X-CSRFToken", csrftoken);
// 		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
// 		xmlhttp.send('date='+date+'&playerJSId='+playerJSId+'&playerName='+playerName+'&trackNum='+trackNum+'&device='+device+'&result='+result+'&time='+time+'&nodeData='+nodeData);
//         }

function stopCar(){
    var button = document.getElementById('Race');
    lastFlag = false;
    clearInterval(player1.raceCar);
    button.disabled = false;
}

function getNodeColors(){
    var prevVel = 0;
    for (var i=0; i < nodeArray.length; i++){
	var nodeColor = ptcontext.getImageData(nodeArray[i].x, nodeArray[i].y, 1, 1).data[0];
	switch (nodeColor) {	// set maxvel based on color
		case 124: //VIOLET
		    nodeArray[i].vel = 1;
		    break;
		case 52: //BLUE
		    nodeArray[i].vel = 3;
		    break;
		case 84: //CYAN
		    nodeArray[i].vel = 5;
		    break;
		case 241: //ORANGE
		    nodeArray[i].vel = 7;
		    break;
		case 215: //RED
		    nodeArray[i].vel = 9;
		    break;
		case 0: //BLACK
		    nodeArray[i].vel = 11;
		    break;
	    }
	//nodeArray[i].accel = nodeArray[i].vel - prevVel;
	prevVel = nodeArray[i].vel;
    }
}
//-----------------------//
//  GRAPHING FUNCTIONS   //
//-----------------------//

function graphinit() {
    
    var graphcanvas = document.getElementById("graph");
    graphcanvas.width = GWIDTH;
    graphcanvas.height = GHEIGHT;
    gcontext = graphcanvas.getContext('2d');
    
    dataArray = [0];

    var graph = getGraph('graph', dataArray);
    graph.Draw();
}

function getGraph(id, data) {
    var graph = new RGraph.Line("graph", dataArray);
    //var gcolor = velcheck();
    graph.Set('chart.background.barcolor1', 'rgba(255,255,255,1)');
    graph.Set('chart.background.barcolor2', 'rgba(255,255,255,1)');
    graph.Set('chart.background.grid.color', 'rgba(238,238,238,1)');
    //graph.Set('chart.text.color', 'rgba(255,255,255,1)');
    graph.Set('chart.colors', ['rgba(255,0,0,1)']);
    graph.Set('chart.linewidth', 2);
    graph.Set('chart.filled', false);
    graph.Set('chart.title.yaxis', 'Velocity');
    graph.Set('chart.ymax', 10);
    graph.Set('chart.title.xaxis', 'Time');
    graph.Set('chart.gutter', 50);
    graph.Set('chart.crosshairs', true);
    
    return graph;
}

function graphupdate() {
    RGraph.Clear(document.getElementById("graph"));
    var graph = getGraph('graph', dataArray);
    graph.Draw();
}

//-------------------//
//  BUTTON FUNCTIONS //
//-------------------//

function paintMode() {
//    if (graphMade){
//	var r = confirm("Returning to paint mode will reset the graph!  Are you sure you want to continue?");
//    }
    resetCar();
    clearGraph();
    document.getElementById("Clear").disabled = false;
    document.getElementById("Reset").disabled = false;
    document.getElementById("Race").disabled = false;
    document.getElementById("resetGraph").style.display = "none";
    document.getElementById("paintMode").style.display = "none";
    document.getElementById("returnGraph").style.display = "none";
    document.getElementById("exportGraph").style.display = "none";
    document.getElementById("graphMode").style.display = "block";
    document.getElementById("showTimes").style.display = "block";
    document.getElementById("square").style.display = "none";
    document.getElementById("corners").style.display = "none";
    document.getElementById("fig8").style.display = "none";
    document.getElementById("graphback").style.zIndex = 0;
    document.getElementById("graphnodes").style.zIndex = 1;
    graphActive = false;
    graphMade = false;
    // clear, reset, race active
    // resetGraph, paintMode, returnGraph, exportGraph hidden
    // graphMode show
}

function graphMode(){
    resetCar();
    document.getElementById("Clear").disabled = true;
    document.getElementById("Reset").disabled = true;
    document.getElementById("Race").disabled = true;
    document.getElementById("resetGraph").style.display = "block";
    document.getElementById("paintMode").style.display = "block";
    document.getElementById("exportGraph").style.display = "block";
    toggleTrackImages();
    document.getElementById("returnGraph").style.display = "none";
    document.getElementById("graphMode").style.display = "none";
    document.getElementById("showTimes").style.display = "none";
    document.getElementById("graphback").style.zIndex = 5;
    document.getElementById("graphnodes").style.zIndex = 6;
    if (activeNode == 0){
	graphSetup();
    }
    graphActive = true;
    // When graphActive = false
    //// clear, reset, race disabled
    //// resetGraph, paintMode, exportGraph show
    //// graphMode, returnGraph hidden
    
    // When graphActive = true
    //// clear, reset, race active
    //// resetGraph, exportGraph, graphMode hidden
    //// paintMode, returnGraph show
}