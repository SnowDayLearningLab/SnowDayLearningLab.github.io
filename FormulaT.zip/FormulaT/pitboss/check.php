<?php

$uScore = $_GET['time'];
$uTrack = $_GET['track'];
$best = $_GET['best']; //true and false are reading as strings rather than boolean
$show = $_GET['show'];

$fileContents = file_get_contents("scores/$uTrack.txt");
$namesList = reset(explode("::", $fileContents));
$scoresList = end(explode("::", $fileContents));
$nArr = explode(",", $namesList);
$sArr = explode(",", $scoresList);

if ($best == "true"){
	$numberOfScores = count($sArr);
	for ($i=0; $i<$numberOfScores; $i++) {
		if ($uScore <= $sArr[$i]) {
			$numScoreToWrite = $i;
			$i = $numberOfScores;
		}
	}
	if (isset($numScoreToWrite) && $numScoreToWrite < 10){
			$status = true;
	} else {
		if ($numberOfScores<10) { // ten scores in list
			$status = true;
		} else {
			$status = false;
		}
	}
}
$display = "";
for ($i=1; $i<=10; $i++) { // ten scores
	$display .= '<tr><td style="width:40px;">' . $i . '</td><td style="width:150px;">' . $nArr[$i-1] . '</td><td style="width:100px;">' . $sArr[$i-1] . '</td></tr>';
}
if ($best == "true"){
	if ($status == true){
		$response = 'Congratulations! You\'ve got one of the fastest times! If you\'d like to add your time to the leaderboard, enter your race driver\'s name below.
		<br><br><strong>NOTE: This name will only be used on the leaderboard and will not be used in the study.</strong>
		<p><input type="text" id="playerName" name="playerName" value="Enter Name"></p>
		<button id="submitButton" name="submitButton" type="button" onclick="checkPlayer()" style="z-index: 6; display: block; position:absolute; left:10px;">Submit!</button>
		<button id="cancelButton" name="cancelButton" type="button" onclick="resetCar()" style="z-index: 6; display: block; position:absolute; left:90px;">Close</button>';
	} else {
		$response = 'You did it! Try to get a faster time or try a different track!<p><strong>Top Scores for the '.$uTrack.' track!</strong></p><table style="top:90px; left:20px;">'.$display.'</table><button id="cancelButton" name="cancelButton" type="button" onclick="resetCar()" style="z-index: 6; display: block; position:absolute; bottom:0px;">Close</button>';
	}
} else if ($show == "false") {
	$response = 'You did it! Try to get a faster time or try a different track!<p><strong>Top Scores for the '.$uTrack.' track!</strong></p><table style="top:90px; left:20px;">'.$display.'</table><button id="cancelButton" name="cancelButton" type="button" onclick="resetCar()" style="z-index: 6; display: block; position:absolute; bottom:0px;">Close</button>';
} else {
	$response = '<p><strong>Top Scores for the '.$uTrack.' track!</strong></p><table style="top:70px; left:20px;">'.$display.'</table><button id="cancelButton" name="cancelButton" type="button" onclick="resetCar()" style="z-index: 6; display: block; position:absolute; bottom:10px;">Close</button>';
}

echo $response;
?>