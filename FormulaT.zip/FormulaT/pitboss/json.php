<?php
$json = file_get_contents('php://input');
//var_dump(json_decode($json, true));
$json_decoded = json_decode($json, true);
echo "1";
$file=fopen('tracks.json','a+');
echo "2";
fwrite($file, $json);
echo "3";
fclose($file);
echo "4";
?>
