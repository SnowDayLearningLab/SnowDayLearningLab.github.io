// Reset Nodes button, only one player car, reset player car button...
// SAVE and LOAD

var WIDTH = 700;
var HEIGHT = 450;
var GWIDTH = 350;
var GHEIGHT = 250;

var name = localStorage.key(0);
var age = localStorage.getItem(name);
var device;

var player1;
var nodeArray;
var id;
var dataArray;
var line;
var component;
var result;
var source = "test";

var drawing;
var touchable = "createTouch" in document;
var bubble = new google.bookmarkbubble.Bubble();
var parameter = 'bmb=1';

function init() {
    setup();
    loadBubble();
}

function setup() {
    var ptcanvas = document.getElementById("paint");
    var trcanvas = document.getElementById("track");
    var carcan = document.getElementById("car");
    var brushSize = document.getElementById("brushSize");
    ptcanvas.width = WIDTH;
    ptcanvas.height = HEIGHT;
    trcanvas.width = WIDTH;
    trcanvas.height = HEIGHT;
    carcan.width = WIDTH;
    carcan.height = HEIGHT;
    ptcontext = ptcanvas.getContext('2d');
    trcontext = trcanvas.getContext('2d');
    carcontx = carcan.getContext('2d');
    
    // Prevent elastic scrolling in iphone / ipad apps
    document.ontouchmove = function(evt) {
	evt.preventDefault();
    }
    
    if (ptcanvas) {
	if (isIPad() || isIPhone()) {
	    carcan.ontouchstart = touchDown;
	    carcan.ontouchmove = touchDrag;
	    carcan.ontouchend = touchUp;
	    device = "touch";
	} else {
	    carcan.onmouseup = mouseUp;
	    carcan.onmousemove = mouseMove;
	    carcan.onmousedown = mouseDown;
	    carcan.onmouseout = mouseOut;
	    device = "mouse";
	}
    }
    
    // create background and grass
    blankBackground(ptcontext);
    grassInit(trcontext);
    drawing = false;  // sets drawing flag to false
    id = 0;
    nodeArray=[];
}

function isIPad() {
    return (navigator.userAgent.indexOf("iPad") != -1);
}

function isIPhone() {
    return (navigator.userAgent.indexOf("iPhone") != -1);
}

function loadBubble() {
    bubble.hasHashParameter = function() {
      return window.location.hash.indexOf(parameter) != -1;
    };
    bubble.setHashParameter = function() {
      if (!this.hasHashParameter()) {
        window.location.hash += parameter;
      }
    };
    bubble.showIfAllowed();
}

function race() {
    var button = document.getElementById('test');
    if (player1.goFlag == 0) {
	result = "success";
	stopCar();
    } else if (player1.goFlag == 2) {
	result = "fail";
	stopCar();
    } else {
        button.disabled = true;
        player1.goFlag = endcheck();
	player1.vel = 1;
        player1.checkNode(player1.x, player1.y);
        player1.update();
        carcontx.clearRect (0, 0, WIDTH, HEIGHT);
        player1.draw(carcontx);
    }
}

function endcheck() {
    var colorAhead = colorcheck(1);
    if (colorAhead.data[0] == 204 && colorAhead.data[1] == 255) {
        //toggle("finishMessage");
        return 0;
    } else if (colorAhead.data[0] == 25){
        //toggle("crashMessage");
        return 2;
    } else {
        return 1;
    }
    return null;
}

function colorcheck(layer) {
    if (layer==1){
	return trcontext.getImageData((player1.x + player1.xvel), (player1.y + player1.yvel), 1, 1);
    } else {
	return ptcontext.getImageData((player1.x + player1.xvel), (player1.y + player1.yvel), 1, 1);
    }
}

function stopCar(){
    var button = document.getElementById('test');
    clearInterval(player1.raceCar);
    button.disabled = false;
}

//-----------------------//
//     TRACK DRAWING     //
//-----------------------//

function nodeDraw(){
    for (var i = 0; i < 20; i++) {
        var curr = nodeArray[i];
        trcontext.fillStyle = "white";
        trcontext.textAlign = "center";
        trcontext.textBaseline = "middle";
        trcontext.fillText(curr.id, curr.x, curr.y);
    }
}

function blankBackground() {
    trcontext.globalCompositeOperation = 'source-over';
    ptcontext.fillStyle = "rgba(0, 0, 0, 1)";  // black canvas
    ptcontext.fillRect(0, 0, WIDTH, HEIGHT);
    carcontx.strokeRect(0, 0, WIDTH, HEIGHT);
}

// the painting function
function paint(mx, my, r, comp) {
    if (comp == 0){
	trcontext.fillStyle = "rgba(0, 0, 0, 1)";
	trcontext.globalCompositeOperation = 'destination-out';
    } else {
	trcontext.fillStyle = "#199B19";
	trcontext.globalCompositeOperation = 'source-over';
    }
    
    document.getElementById("debug").innerHTML = "composite: " + trcontext.globalCompositeOperation;

    trcontext.beginPath();
    trcontext.arc(mx, my, r, 0, Math.PI*2, true);
    trcontext.closePath();
    trcontext.fill();
}

function grassInit(){
    trcontext.fillStyle = "#199B19";
    trcontext.fillRect(0, 0, WIDTH, HEIGHT);
}

function finishLine(mx, my){
    trcontext.globalCompositeOperation = 'destination-over';
    trcontext.fillStyle = "#CCFF33"; // finish line
    trcontext.fillRect(mx-40, my-5, 80, 10);
}

function placeCar(mx, my){
    player1 = new playerCar(mx, my, 0, 0, Math.PI/2, 0);
}

function placeNode(mx, my){
    trcontext.globalCompositeOperation = 'source-over';
    trcontext.fillStyle = "rgba(255,255,255,1)";
    trcontext.textAlign = "center";
    trcontext.textBaseline = "middle";
    nodeArray.push( new node (mx, my, (nodeArray.length + 1), 0, 0));
    //id += 1;
    trcontext.fillText(nodeArray.length, mx, my);
}

function wipeNodes(){
    trcontext.globalCompositeOperation = 'destination-out';
    trcontext.fillStyle = "rgba(0,0,0,1)";
    for (var i=0; i < nodeArray.length; i++){
	n = nodeArray[i];
	trcontext.fillRect(n.x-5, n.y-5, 10, 10)
    }
}

function componentCheck(mx, my, r){
    component = document.getElementById("component").selectedIndex;
    switch (component){
	case 0: // track
	    if (!drawing) {
		drawing = true;
		paint(mx, my, r, component);
	    }
	    break;
	case 1: // erase
	    if (!drawing) {
		drawing = true;
		paint(mx, my, r, component);
	    }
	    break;
	case 2: // finish line
	    finishLine(mx, my);
	    break;
	case 3: // car
	    if (!player1){
		placeCar(mx, my);
		player1.draw(carcontx);
	    }
	    break;
	case 4: // nodes
	    placeNode(mx, my);
	    break;
    }
}

//-----------------------//
//     EVENTS            //
//-----------------------//

function mouseDown(event) {
    //if (!graphActive){
	// get the mouse location
	var mx = event.pageX - 30;
	var my = event.pageY - 30;
	var r = document.getElementById("brushSize").value;
	componentCheck(mx, my, r);
    //}
}

function mouseMove(event) {
    //if (!graphActive){
	var mx = event.pageX - 30;
	var my = event.pageY - 30;
	var r = document.getElementById("brushSize").value;
	if ((component == 0 || component == 1) && drawing){
	    paint(mx, my, r, component);
	}
    //}
}

function mouseUp(event) {
    //if (!graphActive){
    drawing = false; // on mouseup, set the drawing flag to false
    //}
}

function mouseOut(event) {
    //if (!graphActive){
	drawing = false;
    //}
}

function touchDown(event) {
    //if (!graphActive){
	// get the mouse location
	for (var i=0; i<event.changedTouches.length; i++) {
	    var t = event.changedTouches[i];
	    var tx = t.pageX - 30;
	    var ty = t.pageY - 30;
	    var r = document.getElementById("brushSize").value;
	    componentCheck(tx, ty, r)
	}
    //}
}

function touchDrag(event) {
    //if (!graphActive){
	for (var i=0; i<event.changedTouches.length; i++) {
	    var t = event.changedTouches[i];
	    var tx = t.pageX - 30;
	    var ty = t.pageY - 30;
	    var r = document.getElementById("brushSize").value;
	    if ((component == 0 || component == 1) && drawing){
		paint(tx, ty, r, component);
	    }        
	}
    //}
}

function touchUp(event) {
    //if (!graphActive){
	if (event.touches.length == 0) {
	    drawing = false;
	}
    //}
}

//--------------------//
//  BUTTON FUNCTIONS  //
//--------------------//
function testRun(){
    if (nodeArray.length > 0 && player1){
	player1.raceCar = setInterval(race, 30);
    } else {
	//INSERT "NO NODES" ERROR MESSAGE
    }
}

function resetRun(){
    if (player1){
	stopCar();
	carcontx.clearRect (0, 0, WIDTH, HEIGHT);
	player1.x = player1.initx;
	player1.y = player1.inity;
	player1.vel = 0;
	player1.heading = Math.PI/2;
	player1.draw(carcontx);
    }
}

function clearEntities(){
    if (nodeArray.length > 0) {
	wipeNodes();
	nodeArray = [];
    }
    if (player1){
	carcontx.globalCompositeOperation = 'destination-out';
	carcontx.fillStyle = "rgba(0, 0, 0, 1)";
	carcontx.fillRect(player1.x - 17, player1.y - 17, 34, 34); 
	player1 = null;
    }
}

function saveTrack(){
    if (player1 && nodeArray.length > 0){
	var trackIMG = document.getElementById("track").toDataURL("image/png");
	var trackName = document.getElementById("trackName").value;
	var trackObj = new Object;
	trackObj.name = trackName;
	trackObj.car = new Object;
	trackObj.car.x = player1.x;
	trackObj.car.y = player1.y;
	trackObj.track = trackIMG;
	//trackObj.nodes = nodeArray;
	//var trackObj = '{"name" : '+trackName+' , "car" : '+player1+' , "track" : '+trackIMG+' , "nodes" : '+nodeArray+' }';
	var jsonObj = JSON.stringify(trackObj);
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange=function() {
	    // continue if the process is completed
	    if (xmlhttp.readyState == 4) {
		// continue only if HTTP status is "OK"
		if (xmlhttp.status == 200) {
		    tns=xmlhttp.responseText;
		}
	    }
	}
	xmlhttp.open("POST", "json.php", true);
	xmlhttp.setRequestHeader("Content-Type", "'application/x-www-form-urlencoded'");
	xmlhttp.send(jsonObj);
	//xmlhttp.send('name='+trackName+'&car='+player1+'&track='+trackIMG+'&nodes='+nodeArray);
    }
}

function loadTrack(){
    
}