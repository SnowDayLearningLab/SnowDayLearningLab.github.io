<?php
$uScore = $_GET['time'];
$uName = $_GET['playerName'];
$uTrack = $_GET['track'];
$newPlayer = $_GET['newPlayer'];

$fileContents = file_get_contents("scores/$uTrack.txt");
$namesList = reset(explode("::", $fileContents));
$scoresList = end(explode("::", $fileContents));
$nArr = explode(",", $namesList);
$sArr = explode(",", $scoresList);

$numberOfScores = count($sArr);

if ($newPlayer == "false"){
	for ($i=0; $i<$numberOfScores; $i++) {
		if ($uName == $nArr[$i]) {
			unset($sArr[$i]);
			unset($nArr[$i]);
			$numberOfScores = count($sArr);
		}
	}
}

for ($i=0; $i<$numberOfScores; $i++) {
	if ($uScore <= $sArr[$i]) {
		$numScoreToWrite = $i;
		$i = $numberOfScores;
	}
}
if (isset($numScoreToWrite)){
	if ($numScoreToWrite==0) {
		array_unshift($sArr, $uScore);
		array_unshift($nArr, $uName);
		$status = true;
	} else {
		array_splice($sArr, $numScoreToWrite, 0, $uScore);
		array_splice($nArr, $numScoreToWrite, 0, $uName);
		$status = true;
	}
} else {
	if ($numberOfScores<10) { // ten scores in list
		array_push($sArr, $uScore);
		array_push($nArr, $uName);
		$status = true;
	} else {
		$status = false;
	}
}

$toWrite = implode(",", $nArr) . "::" . implode(",", $sArr);
file_put_contents("scores/$uTrack.txt", $toWrite);

$display = "";
for ($i=1; $i<=10; $i++) { // ten scores
	if ($i == ($numScoreToWrite + 1)){
		$display .= '<tr><td style="width:40px;"><strong>' . $i . '</strong></td><td style="width:150px;"><strong>' . $nArr[$i-1] . '</strong></td><td style="width:100px;"><strong>' . $sArr[$i-1] . '</strong></td></tr></strong>';
	} else {
		$display .= '<tr><td style="width:40px;">' . $i . '</td><td style="width:150px;">' . $nArr[$i-1] . '</td><td style="width:100px;">' . $sArr[$i-1] . '</td></tr>';
	}
}

$response = '<p><strong>Top Scores for the '.$uTrack.' track!</strong></p><table style="top:70px; left:20px;">'.$display.'</table><button id="cancelButton" name="cancelButton" type="button" onclick="resetCar()" style="z-index: 6; display: block; position:absolute; bottom:10px;">Close</button>';

echo $response;

?>