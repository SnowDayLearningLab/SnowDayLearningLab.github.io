<?php
$img= $_POST['img'];

$date=$_POST['date'];
$id=$_POST['id'];
$age=$_POST['age'];
$players=$_POST['players'];
$track=$_POST['trackselected'];
$device=$_POST['device'];
$nodeColors=$_POST['nodeData'];

if ($_POST['result']=='win'){
	$result=1;
        $resultT='WIN';
}else{
	$result=0;
        $resultT='FAIL';
}
$path="logs/$id.html";
$nodePath="logs/$id.txt";
$img = str_replace(' ','+',$img);
$data=fopen($path,'a+');
if (!($done)){
	//file_put_contents($logpath, "\n$id tries: 1 wins: $result win ratio: $result",FILE_APPEND);
	fwrite($data, '<html><body><h1>' . $id. ' Age: <span id="age">' . $age . '</span> Num: <span id="players">' . $players . '</span> Data</h1></body>');
	$done=true;
	}
$new='<h1><span id="device">' . $device . '</span> ' . $resultT . ' Date: ' . $date . ' Track: ' . $track . '</h1><img id="image" src='.$img.'></img>';
fwrite($data, $new);
fclose($data);

$nodeFile=fopen($nodePath, "a+");
fwrite($nodeFile, var_export($nodeColors, 1));
fclose($nodeFile);

?>