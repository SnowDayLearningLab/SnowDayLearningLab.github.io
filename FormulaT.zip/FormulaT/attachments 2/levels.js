notice=document.getElementById("notice");
function lvl1start(){
	if (goal==false){
		if ((goal2==true)&&(curtrack.map[curplayer.pos].dpos>=othercar.dpos)&&(curplayer.pos==othercar.pos)){goal=true;}
		if ((curplayer.vel>othercar.vel)&&(curtrack.map[curplayer.pos].dpos<=othercar.dpos)){goal2=true;}
		else{goal2=false;}
	}
	else{
		clearInterval(lvlTimer);
		message();
		level2();
	}
}

function level1(){
	curtrack = new track([new part(100,0,.01,2),new part(100,.01,0,2)]);
	curplayer = new player();
	othercar=new other(1,0); 
	loadSprites();
	lvlTimer=setInterval(lvl1start,50);
	draw();
	avp();
	notice.innerText="Catch up to the other car!";
}
function level2(){
	canvas.fillText("Good Job!",200,300);
	goal2=0;
	goal=false;
	curtrack.map[curplayer.pos].dpos=1;
	othercar.dpos=1;
	curplayer.vel=0;
	othercar.vel=0;
	lvl2Timer=setInterval(lvl2start,50);
}
	
function lvl2start(){
	if (goal==false){
		if (curplayer.pos==othercar.pos){
			if ((curtrack.map[curplayer.pos].dpos<=othercar.dpos+5)&&(curtrack.map[curplayer.pos].dpos>=othercar.dpos-5)){goal2++;}}
		var timer = parseInt(goal2/20);
		if (timer>=5){goal=true;}	

		notice.innerText="Now, stay near the other car for " + (5-timer)+ " seconds";
	}
}

function race(){
	var racetrack=[new part (30,0,0,0),new part(turn1,0,-.01,2),new part(turn2,-.01,-.02,3),new part(turn2,-.02,-.01,3),new part(turn1,-.01,0,2),new part(100,0,0,0),new part(turn1,0,-.01,2),new part(turn2,-.01,-.02,3),new part(turn2,-.02,-.01,3),new part(turn1,-.01,0,2),new part(60,0,0,0)];
	var turn1=40;
	var turn2=55;
}