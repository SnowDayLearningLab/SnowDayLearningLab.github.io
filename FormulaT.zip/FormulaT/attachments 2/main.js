var DDXfactor=0;
canvas=document.getElementById("ground").getContext("2d");
scanvas=document.getElementById("sky").getContext("2d");
scanvas.fillStyle='rgb(100,150,255)'; //skycolor
scanvas.fillRect(0,0,768,424);
info=document.getElementById("info")
info2=document.getElementById("info2")
var test=0;
var test2=0;
var RoadLines = 600;
var flineclr='rgb(255,255,0)';
var grassclr = 'rgb(25,150,25)';
var roadclr = 'rgb(0,0,0)';
var stripeclr = 'rgb(200,255,50)';
var acting = [false,false,false,false]; //left up right down
var ResX = 768;
var ResY = 600;
var halfWidth = 350;
var stripeWidth=halfWidth/30;
var screenLine = ResY - 1;
var yfactor;
var curDX=0
var prevDX=0
var DX;
var DDX;
var sprites=new Array(15);
for (var i=0;i<sprites.length;i++){
	sprites[i]="C:/Users/Srinivas/Desktop/CCL Stuff/3drace/fixed/car"+i+".png";
}
var X = ResX/2;
var y = ResY/20;
var sidemotion=0;
level1();
var lvlTimer;
var drawTimer;
var avpTimer;
var goal=false;
var goal2=false;
var fline=1000;

if (window.DeviceMotionEvent != undefined) {

window.ondevicemotion = function(e) {  
	curplayer.vel += ((Math.abs(event.accelerationIncludingGravity.z)-7) / 300);
    var accelerationX = event.accelerationIncludingGravity.x.toFixed(1);  
    var accelerationY = event.accelerationIncludingGravity.y.toFixed(1);  
    var accelerationZ = event.accelerationIncludingGravity.z.toFixed(1);  
	info2.innerText="X: "+accelerationX+" y "+accelerationY+" z "+accelerationZ
}  
}else{document.onkeydown = Keyon;  document.onkeyup= Keyoff;}


var stripeCount=1;
var stripeFlag=true;

function draw(){
	
	
	var halfWidth=625;
	var widthStep=1;
	var stripeWidth;
	//curve the road
	try{DDX = curtrack.map[curplayer.pos].nextDDX();}
	catch(err){}
	boundCurve(curtrack.map[curplayer.pos]);
	DX=0;
	yfactor=curplayer.vel/10;
	X = ResX/2;
	y = ResY/20;
	stripeWidth=halfWidth/30;
	screenLine = ResY - 1;
	for (var A = 1;A<= RoadLines;A++){
		canvas.strokeStyle=roadclr;
		if ((A>=fline)&&(A<=fline+20)){canvas.strokeStyle=flineclr;}
		drawline(canvas,X-halfWidth, screenLine,X + halfWidth, screenLine);
		canvas.strokeStyle=grassclr;
		drawline(canvas,0, screenLine,X-halfWidth, screenLine);
		drawline(canvas,X+halfWidth, screenLine,ResX - 1, screenLine);

		if (stripeFlag && stripeCount > 0) {
			canvas.strokeStyle=stripeclr;
			drawline(canvas,X-stripeWidth, screenLine,X+stripeWidth, screenLine);
			stripeCount += 1;
		} 
		else if (!stripeFlag && stripeCount > 0) {
			stripeCount += 1;
		}
		if (stripeCount > y) {
			stripeCount = 1;
			stripeFlag = !stripeFlag;
			y -= curplayer.vel/20;
		}
		
		halfWidth = halfWidth - widthStep;
		stripeWidth = halfWidth / 30;
		screenLine = screenLine - 1;
		
		DX = DX + DDX
		X = X + DX
		info.innerText=acting[2]+" "+curplayer.sidevel+" x: "+curplayer.x+" vel: " + curplayer.vel+" pos: "+curplayer.pos+" dpos: "+curtrack.map[curplayer.pos].dpos+" DX: "+DX+" DDX: "+DDX;
	}

	curtrack.map[curplayer.pos].dpos+=curplayer.vel;
	if (curtrack.map[curplayer.pos].dpos >=curtrack.map[curplayer.pos].length) {
		nextpart();
	}
	if (curplayer.pos==curtrack.map.length-1){fline=(lastpos.length-curtrack.map[curplayer.pos].dpos)*30;}
	else{fline=1000;}
	prevDX=curDX;
	curDX=DX;
	if ((prevDX-curDX)!=0){
		if (Math.abs(curtrack.map[curplayer.pos].fcurvature)>Math.abs(curtrack.map[curplayer.pos].icurvature)){
		sidemotion = sidemotion - (curDX-prevDX)+curplayer.sidevel;
		}else {sidemotion = sidemotion - (prevDX-curDX)+curplayer.sidevel;}
		curplayer.x+=sidemotion*3;
	}
	else{curplayer.x+=curplayer.sidevel*50};
	updateOthers();
	drawOthers();
	
	canvas.drawImage(curplayer.orient,curplayer.x,curplayer.y,curplayer.orient.width*curplayer.scale,curplayer.height*curplayer.scale);

	drawTimer=setTimeout(draw,50);
}

function Keyon(e){
		var KeyID = e.which;
		switch(KeyID)
		{
			case 37:
			acting[0]=true;
			break;
			
			case 38:
			acting[1]=true;
			return false;
			break;
			
			case 39:
			acting[2]=true;
			break;
			
			case 40:
			acting[3]=true;
			return false;
			break;
		}
	}
function Keyoff(e){
		var KeyID = e.which;
		switch(KeyID)
		{
			case 37:
			acting[0]=false;

			break;
			case 38:
			acting[1]=false;
			break
			case 39:
			acting[2]=false;

			break;
			case 40:
			acting[3]=false;
			break;
		}
	}
function avp(){
		if (acting[1]){
			curplayer.vel+=curplayer.acc;
		}
		else {
			curplayer.vel-=curplayer.decel;
			if (acting[3]){
				curplayer.vel-=curplayer.acc;
			}
			if(curplayer.vel<0){
				curplayer.vel=0
			}	
		}
		if (acting[0]==true){
			curplayer.sidevel-=curplayer.sideacc;
		}
		else if (acting[2]==true){
			curplayer.sidevel+=curplayer.sideacc;
		}
		if ((acting[0]==false)&&(acting[2]==false)) {
			if (curplayer.sidevel>0){
				if (curplayer.sidevel<curplayer.sidedecel){
					curplayer.sidevel=0
				}
				else {curplayer.sidevel-=curplayer.sidedecel;}
			}
			else if (curplayer.sidevel<0){
				if (curplayer.sidevel>(-curplayer.sidedecel)){
					curplayer.sidevel=0
				}
				else {curplayer.sidevel+=curplayer.sidedecel;}
			}
		}
		if (curplayer.sidevel>curplayer.maxsidevel){
			curplayer.sidevel=curplayer.maxsidevel;
		}
		else if (curplayer.sidevel<(-curplayer.maxsidevel)){
			curplayer.sidevel=-curplayer.maxsidevel;
		}
		playerSprite();
		avpTimer = setTimeout(avp,50);
}
	
function updateOthers(){
	othercar.vel+=othercar.acc;
	if (othercar.vel>=othercar.mvel){
		othercar.vel=othercar.mvel;
	}
	othercar.dpos+=othercar.vel;
	if (othercar.dpos >=curtrack.map[othercar.pos].length) {
		othercar.pos+=1;
		othercar.pos%=curtrack.map.length;
		othercar.dpos=0;
	}
	otherSprite();
}

function drawOthers(){
		if (curplayer.pos==othercar.pos){
			if (othercar.dpos>=curtrack.map[curplayer.pos].dpos&&othercar.dpos<=curtrack.map[curplayer.pos].dpos+40){
				distance=othercar.dpos-curtrack.map[curplayer.pos].dpos;
				othercar.ycoord=othercar.y-distance*15
				DDXfactor=DDX*300*(450-othercar.ycoord);
				othercar.xcoord=othercar.x-.6*othercar.ycoord+DDXfactor;
				canvas.drawImage(othercar.orient,othercar.xcoord,othercar.ycoord,othercar.orient.width*((40-distance)/40),othercar.height*((40-distance)/40));
			}
		}else if(othercar.pos==(curplayer.pos+1)%curtrack.map.length){
	
			if (curtrack.map[curplayer.pos].length-curtrack.map[curplayer.pos].dpos+othercar.dpos<=25){
				info2.innerText="22";
				distance=othercar.dpos-curtrack.map[curplayer.pos].dpos;
				othercar.ycoord=othercar.y-distance*15
				DDXfactor=DDX*300*(450-othercar.ycoord);
				othercar.xcoord=othercar.x-.6*othercar.ycoord+DDXfactor;
				canvas.drawImage(othercar.orient,othercar.xcoord,othercar.ycoord,othercar.orient.width*((40-distance)/40),othercar.height*((40-distance)/40));
			}
		info2.innerText=distance+" "+othercar.vel+" pos "+othercar.pos+" dpos "+othercar.dpos+ " xcoord "+" length "+curtrack.map[curplayer.pos].length+" dpos: "+curtrack.map[curplayer.pos].dpos;
		}
}