function nextpart(){
	curplayer.pos=curplayer.pos+1;
	curplayer.pos=curplayer.pos%curtrack.map.length;
	curtrack.map[curplayer.pos].dpos=0;
}

function drawline(contextO, startx, starty, endx, endy) {
  contextO.beginPath();
  contextO.moveTo(startx, starty);
  contextO.lineTo(endx, endy);
  contextO.closePath();
  contextO.stroke();
}

function isIPad() {
    return (navigator.userAgent.indexOf("iPad") != -1);
}

function isIPhone() {
    return (navigator.userAgent.indexOf("iPhone") != -1);
}
function message() {
	var msgCanvas=document.getElementById('msg');
	msgCanvas.setAttribute('style','z-index:2;position:absolute;left:0px;top:0px;');
	var msgCtx=msgCanvas.getContext('2d');
	msgCtx.fillStyle='rgb(100,150,255)'; //skycolor
	msgCtx.fillRect(0,0,768,424);
}
function boundCurve(part){
	if(part.fcurvature>part.icurvature){
		if (DDX>=part.fcurvature){
			DDX=part.fcurvature;
		}
		else if(DDX<=part.icurvature){
			DDX=part.icurvature;
		}
	}
	else if(part.fcurvature<part.icurvature){
		if (DDX<=part.fcurvature){
			DDX=part.fcurvature;
		}
		else if(DDX>=part.icurvature){
			DDX=part.icurvature;
		}
	}
	else{}
}

function loadSprites(){
	for (var i=0;i<14;i++){
		curplayer.orient.src=sprites[i];
	}
}

	
function playerSprite(){
	curplayer.orient.src=sprites[7-Math.floor(curplayer.sidevel/.03)];
}

function otherSprite(){
	var x=Math.floor(DDX/.0005);
	if(x>7){x=7;}
	othercar.orient.src=sprites[7-x];
}