function player(){
	this.vel = 0;
	this.acc = .03;
	this.decel = .01;
	this.brakeacc = 1;
	this.pos = 0;
	this.x = 450;
	this.y = 450;
	this.orient=new Image();
	this.maxsidevel = .12;
	this.maxvel;
	this.sidevel = 0;
	this.sideacc = .03;
	this.sidedecel = .09;
	this.scale = 1;
	this.width=120;
	this.height=90;
}

function other(mvel,lvl){
	this.vel = 0;
	this.acc=.05;
	this.mvel=mvel;
	this.lvl=lvl;
	this.pos = 0;
	this.dpos = 0;
	this.x = 350;
	this.y = 450;
	this.prevDX=0;
	this.curDX;
	this.orient=new Image();
	this.sidevel = 0;
	this.sideacc = .01;
	this.sidedecel = 1;
	this.scale = 1;
	this.width=120;
	this.height=90;
	this.ycoord;
}

function part(length,icurvature,fcurvature,curvature){
	this.length=length;
	this.icurvature=icurvature;
	this.fcurvature=fcurvature;
	this.curvature=curvature;
	this.dpos=0;
	this.nextDDX = function(){return(0)};
	this.init = function(){
		if (this.fcurvature>this.icurvature){
			this.nextDDX = function(){
				return((this.dpos*.0001*curvature)+this.icurvature);
			}
		}
		else if (this.fcurvature<this.icurvature){
			this.nextDDX = function(){
				return(this.icurvature-(this.dpos*.0001*curvature));
			}
		}
		else {
			this.nextDDX=function(){return(0)}
		}
	}
}
function track(map){
	this.map=map
	for (var i = 0;i<this.map.length;i++){
		this.map[i].init();
	}
	lastpos=map[map.length-1];
	this.frameRate=50;
}