var DDXfactor = 0;
var canvas;
var scanvas;
var info;
var info2;
var info3;
var notice;
var initflag;
var test = 0;
var test2 = 0;
var basex;
var basey;
var flineclr = 'rgb(255,255,0)';
var grassclr = 'rgb(25,150,25)';
var roadclr = 'rgb(0,0,0)';
var stripeclr = 'rgb(200,255,50)';
var acting = [ false, false, false, false ]; // left up right down
var ResX = 400;
var ResY = 250;
var roadRatio = Math.floor(ResX * 130 / 400);
var RoadLines = ResY;
var screenLine = ResY - 1;
var curDX = 0
var prevDX = 0
var DX;
var DDX;
var sprites = new Array(15);

var X = ResX / 2;
var Y = ResY / 20;
var sidemotion = 0;

var lvlTimer;
var drawTimer;
var avpTimer;
var goal = false;
var goal2 = false;
var fline = 1000;

var GWIDTH = 200;
var GHEIGHT = 150;
var dataArray;

//initializes the variables for canvases/contexts/sprites/graph
//fills the sky and starts the level

function init() {
	initflag = true;
	canvas = document.getElementById("ground").getContext("2d");
	scanvas = document.getElementById("sky").getContext("2d");
	info = document.getElementById("info");
	info2 = document.getElementById("info2");
	info3 = document.getElementById("info3");
	notice = document.getElementById("notice");
	scanvas.fillStyle = 'rgb(100,150,255)'; // skycolor
	scanvas.fillRect(0, 0, 1024, 268);
	for ( var i = 0; i < sprites.length; i++) {
		var path = "sprites/car" + i + ".png";
		sprites[i] = path;
	}
	graphinit();
	level1();
}

function startRace() {
	initflag = false;
	lvlTimer = setInterval(lvl1start, 50);
	avp();
	notice.innerText = "Catch up to the other car!";
}

//check if motion event is defined, else bind to arrow keys

if (window.DeviceMotionEvent != undefined) {

	window.ondevicemotion = function (event) {
		if (initflag) {
			basex = event.accelerationIncludingGravity.x.toFixed(1);
			basey = event.accelerationIncludingGravity.y.toFixed(1);
			info3.innerText = "X: " + basex + " Y: " + basey;
		} else {
		//curplayer.vel += ((Math.abs(event.accelerationIncludingGravity.z) - 7) / 300);
		
		var accelerationX = event.accelerationIncludingGravity.x.toFixed(1);
		var accelerationY = event.accelerationIncludingGravity.y.toFixed(1);
		var accelerationZ = event.accelerationIncludingGravity.z.toFixed(1);
		
		updatePlayerVelocity(accelerationX, accelerationY);
		}
	}
} else {
	document.onkeydown = Keyon;
	document.onkeyup = Keyoff;
}

function updatePlayerVelocity (X, Y){
	curplayer.vel = (basex - X) / 4;
	curplayer.sidevel = (basey - Y) / -2;
	info.innerText = "vel: " + curplayer.vel + " sidevel: " + curplayer.sidevel;
	if (curplayer.vel < 0) {
		curplayer.vel = 0
	}
}

//set variables to handle stripes and road width increments
var stripeCount = 1;
var stripeFlag = true;
var widthStep = .4;

//main draw loop, get curvature, then draw with horizontal lines one at a time in a loop
function draw() {

	var halfWidth = roadRatio;
	var stripeWidth = halfWidth / 16;
	stripeCount = 1;
	// curve the road
	try {
		DDX = curtrack.map[curplayer.pos].nextDDX();
	} catch (err) {
	}
	//if curvature function returns over max curvature of the part, will get bound
	boundCurve(curtrack.map[curplayer.pos]);
	DX = 0;
	X = ResX / 2;
	Y = ResY / 20;

	screenLine = ResY - 1;
	for ( var A = 1; A <= RoadLines; A++) {
		canvas.strokeStyle = roadclr;
		if ((A >= fline) && (A <= fline + 20)) {
			canvas.strokeStyle = flineclr;
		}
		drawline(canvas, X - halfWidth, screenLine, X + halfWidth, screenLine);
		canvas.strokeStyle = grassclr;
		drawline(canvas, 0, screenLine, X - halfWidth, screenLine);
		drawline(canvas, X + halfWidth, screenLine, ResX - 1, screenLine);

		if (stripeFlag && stripeCount > 0) {
			canvas.strokeStyle = stripeclr;
			drawline(canvas, X - stripeWidth, screenLine, X + stripeWidth,
					screenLine);
			stripeCount += 1;
		} else if (!stripeFlag && stripeCount > 0) {
			stripeCount += 1;
		}
		if (stripeCount > Y) {
			stripeCount = 1;
			stripeFlag = !stripeFlag;
			Y -= curplayer.vel / 10;
		}
		//lower width (road gets narrower into the distance)
		halfWidth = halfWidth - widthStep;
		//lowers width of stripe by corresponding amount
		stripeWidth = halfWidth / 20;
		//moves up one vertically to next line
		screenLine = screenLine - 1;

		DX = DX + DDX
		X = X + DX
		//info.innerText = acting[2] + " " + curplayer.sidevel + " x: "
		//		+ curplayer.x + " vel: " + curplayer.vel + " pos: "
		//		+ curplayer.pos + " dpos: " + curtrack.map[curplayer.pos].dpos
		//		+ " DX: " + DX + " DDX: " + DDX;
	}
	//move player forward, place in next part if end of current part has been reached
	curtrack.map[curplayer.pos].dpos += curplayer.vel;
	if (curtrack.map[curplayer.pos].dpos >= curtrack.map[curplayer.pos].length) {
		nextpart();
	}
	//set finish line if in last part
	if (curplayer.pos == curtrack.map.length - 1) {
		fline = (lastpos.length - curtrack.map[curplayer.pos].dpos) * 30;
	} else {
		fline = 1000;
	}
	
	//USE TO DISPLAY VARIABLES FOR DEBUGGING
	/*
	 * prevDX=curDX; curDX=DX; if ((prevDX-curDX)!=0){ if
	 * (Math.abs(curtrack.map[curplayer.pos].fcurvature)>Math.abs(curtrack.map[curplayer.pos].icurvature)){
	 * sidemotion = sidemotion - (curDX-prevDX)+curplayer.sidevel; }else
	 * {sidemotion = sidemotion - (prevDX-curDX)+curplayer.sidevel;}
	 * curplayer.x+=sidemotion*3; } else{curplayer.x+=curplayer.sidevel*50};
	 */
	
	if (!initflag){
		//create side drag from road turns. Tweak constants to change amount of turn 
		//var sidedrag = -DDX * 200;
		//sidemotion = Math.pow(curplayer.vel, 2) + curplayer.sidevel;
		curplayer.x += curplayer.sidevel * 4;
		//update positions of other cars
		updateOthers();
		//draw updated other cars
		drawOthers();
		//update graph
		graphupdate();
	}
	//draw player, using x and y coord to scale. Y scale is still here incase vertical movement is added
	canvas.drawImage(curplayer.orient, curplayer.x, curplayer.y,
			curplayer.orient.width * curplayer.scale, curplayer.height
					* curplayer.scale);
	//call again in 50ms
	drawTimer = setTimeout(draw, 50);
}
//start acting "forces" on key down events
//acting 0 is left
//1 is up
//2 is right
//3 is down
function Keyon(e) {
	var KeyID = e.which;
	switch (KeyID) {
	case 37:
		acting[0] = true;
		break;

	case 38:
		acting[1] = true;
		return false;
		break;

	case 39:
		acting[2] = true;
		break;

	case 40:
		acting[3] = true;
		return false;
		break;
	}
}
//stop forces on key up events
function Keyoff(e) {
	var KeyID = e.which;
	switch (KeyID) {
	case 37:
		acting[0] = false;

		break;
	case 38:
		acting[1] = false;
		break
	case 39:
		acting[2] = false;

		break;
	case 40:
		acting[3] = false;
		break;
	}
}
//update velocities from a constant acceleration value. 
//Velocity can be bound here if a limit is ever needed
function avp() {
	if (acting[1]) {
		curplayer.vel += curplayer.acc;
	} else {
		curplayer.vel -= curplayer.decel;
		if (acting[3]) {
			curplayer.vel -= (curplayer.acc * 2.5);
		}
		if (curplayer.vel < 0) {
			curplayer.vel = 0
		}
	}
	//turn keys add to the angle
	if (acting[0] == true && curplayer.vel > 0) {
		curplayer.turn+=curplayer.theta;
	} else if (acting[2] == true && curplayer.vel > 0) {
		curplayer.turn-=curplayer.theta;
	} else {
		if (curplayer.turn < 90) {
			curplayer.turn += 2;
		} else if (curplayer.turn > 90) {
			curplayer.turn -= 2;
		} else {
			curplayer.turn = 90;
		}
	}
	//angle bound to min of 12 and max of 168
	if (curplayer.turn<12){
		curplayer.turn=12;
	}
	if (curplayer.turn>168){
		curplayer.turn=168;
	}
	//add to graph
	dataArray.push(curplayer.vel * 5);
	if (dataArray.length > 100){
	    dataArray.shift();
	}
	//side velocity calculated by Hyp*Cos(theta) 
	//a constant factor can be added if it is too slow or fast
	curplayer.sidevel=curplayer.vel*Math.cos(curplayer.turn);
	//checks angle and sets correct sprite
	playerSprite();
	//repeat in 50ms
	avpTimer = setTimeout(avp, 50);
}

//increase velocity till it hits max velocity (set at creation)
function updateOthers() {
	othercar.vel += othercar.acc;
	if (othercar.vel >= othercar.mvel) {
		othercar.vel = othercar.mvel;
	}
	othercar.dpos += othercar.vel;
	//move other car
	if (othercar.dpos >= curtrack.map[othercar.pos].length) {
		othercar.pos += 1;
		othercar.pos %= curtrack.map.length;
		othercar.dpos = 0;
	}
	//set sprite based on curve
	otherSprite();
}

//draw other cars and use distance to scale
function drawOthers() {
	if (curplayer.pos == othercar.pos) {
		if (othercar.dpos >= curtrack.map[curplayer.pos].dpos
				&& othercar.dpos <= curtrack.map[curplayer.pos].dpos + 20) {
			distance = othercar.dpos - curtrack.map[curplayer.pos].dpos;
			othercar.ycoord = othercar.y - distance * 15
			DDXfactor = DDX * 100 * (240 - othercar.ycoord);
			othercar.xcoord = othercar.x - .3 * othercar.ycoord + DDXfactor;
			canvas.drawImage(othercar.orient, othercar.xcoord, othercar.ycoord,
					othercar.scale * othercar.orient.width
							* ((20 - distance) / 20), othercar.scale
							* othercar.height * ((20 - distance) / 20));
		}
	} else if (othercar.pos == (curplayer.pos + 1) % curtrack.map.length) {

		if (curtrack.map[curplayer.pos].length
				- curtrack.map[curplayer.pos].dpos + othercar.dpos <= 20) {
			//info2.innerText = "22";
			distance = othercar.dpos - curtrack.map[curplayer.pos].dpos;
			othercar.ycoord = othercar.y - distance * 10
			DDXfactor = DDX * 150 * (450 - othercar.ycoord);
			othercar.xcoord = othercar.x - .3 * othercar.ycoord + DDXfactor;
			canvas.drawImage(othercar.orient, othercar.xcoord, othercar.ycoord,
					othercar.scale * othercar.orient.width
							* ((20 - distance) / 20), othercar.scale
							* othercar.height * ((20 - distance) / 20));
		}
		//info2.innerText = distance + " " + othercar.vel + " pos "
		//		+ othercar.pos + " dpos " + othercar.dpos + " xcoord "
		//		+ " length " + curtrack.map[curplayer.pos].length + " dpos: "
		//		+ curtrack.map[curplayer.pos].dpos;
	}
}

function graphinit() {
    var graphcanvas = document.getElementById("graph");
    graphcanvas.width = GWIDTH;
    graphcanvas.height = GHEIGHT;
    gcontext = graphcanvas.getContext('2d');
    
    dataArray = [0];

    var graph = getGraph('graph', dataArray);
    graph.Draw();
}

function getGraph(id, data) {
    var graph = new RGraph.Line("graph", dataArray);
    //var gcolor = velcheck();
    graph.Set('chart.background.barcolor1', 'rgba(255,255,255,0)');
    graph.Set('chart.background.barcolor2', 'rgba(255,255,255,0)');
    graph.Set('chart.background.grid.color', 'rgba(238,238,238,1)');
    //graph.Set('chart.text.color', 'rgba(255,255,255,1)');
    graph.Set('chart.colors', ['rgba(255,0,0,1)']);
    graph.Set('chart.linewidth', 2);
    graph.Set('chart.filled', false);
    graph.Set('chart.ymax', 10);

    //graph.Set('chart.title.yaxis', 'Velocity');
    //graph.Set('chart.title.xaxis', 'Time');
    graph.Set('chart.gutter', 20);
    graph.Set('chart.crosshairs', true);
    
    return graph;
}

function graphupdate() {
    RGraph.Clear(document.getElementById("graph"));
    var graph = getGraph('graph', dataArray);
    graph.Draw();
}