//the player object controls all the attributes of the controlled car (vel, acc, etc)
//acc is a constant and is added to velocity as the keys are held down
//left and right works the same way but with the angle theta
//x and y are the starting coordinates
function player() {
	this.vel = 0;
	this.acc = .03;
	this.decel = .01;
	this.brakeacc = 1;
	this.pos = 0;
	this.x = 250;
	this.y = 200;
	this.orient = new Image();
	this.maxsidevel = .12;
	this.maxvel;
	this.sidevel = 0;
	this.sideacc = .03;
	this.sidedecel = .09;
	this.scale = .5;
	this.width = 120;
	this.height = 90;
	this.turn=90;
	this.theta=1;
}

//max vel and lvl are set by parameters at instatiation. lvl is difficulty (currently unimplemented)
//but it could be used to set how well it follows the curve and the odds of it crashing

function other(mvel, lvl) {
	this.vel = 0;
	this.acc = .05;
	this.mvel = mvel;
	this.lvl = lvl;
	this.pos = 0;
	this.dpos = 0;
	this.x = 200;
	this.y = 200;
	this.prevDX = 0;
	this.curDX;
	this.orient = new Image();
	this.sidevel = 0;
	this.sideacc = .01;
	this.sidedecel = 1;
	this.scale = .5;
	this.width = 120;
	this.height = 90;
	this.ycoord;
}
//A part has its own length, dpos (current position of camera on this part) and curvature information
//the curve starts at icurvature and goes towards fcurvature at the specified rate (curvature) and is bound there
function part(length, icurvature, fcurvature, curvature) {
	this.length = length;
	this.icurvature = icurvature;
	this.fcurvature = fcurvature;
	this.curvature = curvature;
	this.dpos = 0;
	this.nextDDX = function() {
		return (0)
	};
	this.init = function() {
		if (this.fcurvature > this.icurvature) {
			this.nextDDX = function() {
				return ((this.dpos * .0001 * curvature) + this.icurvature);
			}
		} else if (this.fcurvature < this.icurvature) {
			this.nextDDX = function() {
				return (this.icurvature - (this.dpos * .0001 * curvature));
			}
		} else {
			this.nextDDX = function() {
				return (0)
			}
		}
	}
}

//made of parts, has current position information
function track(map) {
	this.map = map
	for ( var i = 0; i < this.map.length; i++) {
		this.map[i].init();
	}
	lastpos = map[map.length - 1];
	this.frameRate = 50;
}