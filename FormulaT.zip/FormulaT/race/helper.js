//sets player pos to next part
function nextpart(){
	curplayer.pos=curplayer.pos+1;
	curplayer.pos=curplayer.pos%curtrack.map.length;
	curtrack.map[curplayer.pos].dpos=0;
}
//line drawing function
function drawline(contextO, startx, starty, endx, endy) {
  contextO.beginPath();
  contextO.moveTo(startx, starty);
  contextO.lineTo(endx, endy);
  contextO.closePath();
  contextO.stroke();
}

function isIPad() {
    return (navigator.userAgent.indexOf("iPad") != -1);
}

function isIPhone() {
    return (navigator.userAgent.indexOf("iPhone") != -1);
}
//pops up message div
function messageOn(str) {
	var msg=document.getElementById('msg');
	msg.innerHTML=str;
	msg.style.display="block";
}
//hides message div
function messageOff() {
	var msg=document.getElementById('msg');
	msg.style.display="none";
}
//limit curvature to max curvature of the part
function boundCurve(part){
	if(part.fcurvature>part.icurvature){
		if (DDX>=part.fcurvature){
			DDX=part.fcurvature;
		}
		else if(DDX<=part.icurvature){
			DDX=part.icurvature;
		}
	}
	else if(part.fcurvature<part.icurvature){
		if (DDX<=part.fcurvature){
			DDX=part.fcurvature;
		}
		else if(DDX>=part.icurvature){
			DDX=part.icurvature;
		}
	}
	else{}
}
//preload all sprites to be cached
function loadSprites(){
	for (var i=0;i<14;i++){
		curplayer.orient.src=sprites[i];
	}
}

//sets player sprite using current angle
function playerSprite(){
	curplayer.orient.src=sprites[7+Math.floor((curplayer.turn-90)/25)];
}
//sets other cars sprite using curvature
function otherSprite(){
	var x=Math.floor(DDX/.0005);
	if(x>7){x=7;}
	othercar.orient.src=sprites[7-x];
}